package com.example.demo_login.config.auth;

public class SessionUser {
}
