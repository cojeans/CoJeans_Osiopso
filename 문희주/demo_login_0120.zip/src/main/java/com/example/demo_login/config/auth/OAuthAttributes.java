package com.example.demo_login.config.auth;

import lombok.Builder;
import lombok.Getter;

import java.util.Map;

@Getter
public class OAuthAttributes {
    private Map<String, Object> attributes; // OAuth2 반환하는 유저 정보 Map
    private String nameAttributeKey;
    private String name;
    private String email;
    private String picture;

    @Builder
    public OAuthAttributes(Map<String, Object> attributes, String nameAttributeKey, String name, String email, String picture) {
        this.attributes = attributes;
        this.nameAttributeKey = nameAttributeKey;
        this.name = name;
        this.email = email;
        this.picture = picture;
    }

    public static OAuthAttributes of(String registrationId, String userNameAttributeName, Map<String, Object> attributes){
        // 여기서 네이버, 카카오, 구글 구분(ofNaver, ofKakao, ofGoogle)
        switch (registrationId) {
            case "google":
                return null;
            case "naver":
                return ofNaver(userNameAttributeName, attributes);
            case "kakao":
                return null;
        }

        // TODO: Exception 발생
        return null;
    }

    private static OAuthAttributes ofNaver(String userNameAttributeName, Map<String, Object> attributes){
        // 네이버는 response에 유저정보 존재
    }
}
