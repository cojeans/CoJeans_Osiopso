package com.example.demo_login.config.auth;


import com.example.demo_login.domain.User.Role;
import com.example.demo_login.domain.User.User;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Builder
@AllArgsConstructor
@Getter
@NoArgsConstructor
public class SessionUser implements Serializable {
    private Long id;
    private String name;
    private String email;
    private String picture;
    private Role role;

    public SessionUser(User user){
        id = user.getId();
        name = user.getName();
        email = user.getEmail();
        picture = user.getPicture();
        role = user.getRole();
    }
}
