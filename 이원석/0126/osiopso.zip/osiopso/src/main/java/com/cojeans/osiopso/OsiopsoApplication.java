package com.cojeans.osiopso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OsiopsoApplication {

    public static void main(String[] args) {
        SpringApplication.run(OsiopsoApplication.class, args);
    }

}
