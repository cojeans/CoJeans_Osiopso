package com.cojeans.osiopso.api.dto;

public class TestDto {
}
