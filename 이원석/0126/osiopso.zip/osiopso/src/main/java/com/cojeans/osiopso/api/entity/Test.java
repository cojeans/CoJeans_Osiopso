package com.cojeans.osiopso.api.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Test {

    @Id
    private Long id;
}
