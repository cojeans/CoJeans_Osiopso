package com.cojeans.osiopso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OsiopsoApplicationTests {

    @Test
    void contextLoads() {
    }

}
