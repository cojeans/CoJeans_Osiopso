package com.cojeans.osiopso.api.dto.enumerate;

public enum MemberProvider {
    KAKAO,
    GOOGLE
    ;
}
